export const environment = {
  production: true,
  API_URL: 'https://www.api.e.appointment.erengaygusuz.com.tr/api',
  ENCRYPT_DECRYPT_KEY: '1203199320052021',
  ENCRYPT_DECRYPT_IV: '1203199320052021'
};
