export const environment = {
  production: false,
  API_URL: 'https://localhost:7224/api',
  ENCRYPT_DECRYPT_KEY: '1203199320052021',
  ENCRYPT_DECRYPT_IV: '1203199320052021'
};
