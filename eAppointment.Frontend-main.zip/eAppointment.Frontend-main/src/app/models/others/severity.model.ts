export class Severity {
  value: string = '';
  color: string = '';
  translatedText: string = '';
}
