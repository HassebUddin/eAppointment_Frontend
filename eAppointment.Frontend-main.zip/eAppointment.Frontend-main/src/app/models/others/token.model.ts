export class TokenModel {
  id: string = '';
  name: string = '';
  email: string = '';
  userName: string = '';
  patientId: string = '';
  doctorId: string = '';
  role: string = '';
  permissions: string[] = [];
}
