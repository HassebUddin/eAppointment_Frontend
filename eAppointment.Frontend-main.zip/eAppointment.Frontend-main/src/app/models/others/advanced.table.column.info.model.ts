export class AdvancedTableColumnInfoModel {
  field: string = '';
  sortField: string = '';
  header: string = '';
  isSeverity: boolean = false;
  isOperationColumn: boolean = false;
  isFilterableAndSortable: boolean = false;
}
