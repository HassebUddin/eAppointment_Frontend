export class ExportOptionModel {
  label: string = '';
  value: number = 0;
  iconName: string = '';
  color: string = '';
}
