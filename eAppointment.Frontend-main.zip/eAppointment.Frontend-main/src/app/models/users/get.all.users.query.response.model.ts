export class GetAllUsersQueryResponseModel {
  id: number = 0;
  fullName: string = '';
  email: string = '';
  username: string = '';
  roleNames: string[] = [];
}
