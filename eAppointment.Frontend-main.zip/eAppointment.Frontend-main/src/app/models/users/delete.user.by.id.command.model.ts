export class DeleteUserByIdCommandModel {
  id: number = 0;
}
