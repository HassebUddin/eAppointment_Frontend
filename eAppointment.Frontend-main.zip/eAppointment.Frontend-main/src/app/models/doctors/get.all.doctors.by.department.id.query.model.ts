export class GetAllDoctorsByDepartmentIdQueryModel {
  departmentId: number = 0;
}
