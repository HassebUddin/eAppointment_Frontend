export class GetDoctorProfileByIdQueryModel {
  id: number = 0;
}
