export class GetDoctorByIdQueryModel {
  id: number = 0;
}
