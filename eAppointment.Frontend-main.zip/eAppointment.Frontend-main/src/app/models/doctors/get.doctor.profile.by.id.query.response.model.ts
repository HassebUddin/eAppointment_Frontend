export class GetDoctorProfileByIdQueryResponseModel {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  phoneNumber: string = '';
  userName: string = '';
  departmentId: number = 0;
  profilePhotoContentType: string = '';
  profilePhotoBase64Content: string = '';
}
