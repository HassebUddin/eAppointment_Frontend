export class UpdateDoctorByIdCommandModel {
  id: number = 0;
  firstName: string = '';
  lastName: string = '';
  phoneNumber: string = '';
  email: string = '';
  userName: string = '';
  departmentId: number = 0;
}
