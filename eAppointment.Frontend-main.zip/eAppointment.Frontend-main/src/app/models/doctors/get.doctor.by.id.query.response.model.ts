export class GetDoctorByIdQueryResponseModel {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  phoneNumber: string = '';
  userName: string = '';
  departmentId: number = 0;
}
