export class CreateDoctorCommandModel {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  phoneNumber: string = '';
  userName: string = '';
  password: string = '';
  departmentId: number = 0;
}
