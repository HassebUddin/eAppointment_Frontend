export class GetAllDoctorsByDepartmentIdQueryResponseModel {
  id: number = 0;
  fullName: string = '';
}
