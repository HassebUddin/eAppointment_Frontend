export class GetAllCountiesByCityIdQuerymodel {
  cityId: number = 0;
}
