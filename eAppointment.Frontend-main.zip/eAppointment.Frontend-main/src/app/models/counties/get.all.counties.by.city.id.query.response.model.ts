export class GetAllCountiesByCityIdQueryResponseModel {
  id: number = 0;
  name: string = '';
}
