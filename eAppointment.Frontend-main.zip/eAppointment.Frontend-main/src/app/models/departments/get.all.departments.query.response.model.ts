export class GetAllDepartmentsQueryResponseModel {
  id: number = 0;
  name: string = '';
}
