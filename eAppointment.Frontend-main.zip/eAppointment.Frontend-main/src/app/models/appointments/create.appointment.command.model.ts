export class CreateAppointmentCommandModel {
  startDate: string = '';
  endDate: string = '';
  patientId: number = 0;
  doctorId: number = 0;
}
