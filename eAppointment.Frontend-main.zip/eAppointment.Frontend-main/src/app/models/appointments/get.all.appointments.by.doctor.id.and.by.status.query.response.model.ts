export class GetAllAppointmentsByDoctorIdAndByStatusQueryResponseModel {
  id: string = '';
  fullName: string = '';
  startDate: string = '';
  endDate: string = '';
  status: string = '';
}
