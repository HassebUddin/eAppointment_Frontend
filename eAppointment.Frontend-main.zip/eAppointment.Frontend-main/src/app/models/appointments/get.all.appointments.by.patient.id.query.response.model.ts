export class GetAllAppointmentsByPatientIdQueryResponseModel {
  departmentName: string = '';
  doctorName: string = '';
  startDate: string = '';
  endDate: string = '';
  status: string = '';
}
