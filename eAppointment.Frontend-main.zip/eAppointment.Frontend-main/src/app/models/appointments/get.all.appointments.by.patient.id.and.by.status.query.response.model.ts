export class GetAllAppointmentsByPatientIdAndByStatusQueryResponseModel {
  id: string = '';
  startDate: string = '';
  endDate: string = '';
  title: string = '';
}
