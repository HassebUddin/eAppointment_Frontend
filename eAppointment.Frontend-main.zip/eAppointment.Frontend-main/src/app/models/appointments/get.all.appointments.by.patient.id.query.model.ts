export class GetAllAppointmentsByPatientIdQueryModel {
  patientId: number = 0;
  status: number = 0;
}
