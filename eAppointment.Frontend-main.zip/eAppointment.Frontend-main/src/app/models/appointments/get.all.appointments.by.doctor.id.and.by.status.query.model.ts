export class GetAllAppointmentsByDoctorIdAndByStatusQueryModel {
  doctorId: number = 0;
  status: number = 0;
}
