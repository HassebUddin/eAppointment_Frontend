export class CancelAppointmentByIdCommandModel {
  id: number = 0;
}
