export class UpdateAppointmentByIdCommandModel {
  id: number = 0;
  startDate: string = '';
  endDate: string = '';
  status: number = 0;
}
