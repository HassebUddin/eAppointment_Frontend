export class GetAllAppointmentsByPatientIdAndByStatusQueryModel {
  patientId: number = 0;
  status: number = 0;
}
