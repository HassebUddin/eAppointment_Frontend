import { MenuItem } from 'primeng/api';

export class GetMenuItemsQueryResponseModel {
  items: MenuItem[] = [];
}
