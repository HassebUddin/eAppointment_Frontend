export class GetAllRolesQueryResponseModel {
  id: string = '';
  name: string = '';
}
