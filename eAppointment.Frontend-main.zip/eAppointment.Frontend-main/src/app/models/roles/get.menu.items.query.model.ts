export class GetMenuItemsQueryModel {
  roleName: string = '';
}
