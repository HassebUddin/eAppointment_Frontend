export class LoginCommandModel {
  userName: string = '';
  password: string = '';
}
