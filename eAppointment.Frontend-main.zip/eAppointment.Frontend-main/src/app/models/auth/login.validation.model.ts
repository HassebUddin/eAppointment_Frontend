export class LoginValidationModel {
  userName: string = '';
  password: string = '';
}
