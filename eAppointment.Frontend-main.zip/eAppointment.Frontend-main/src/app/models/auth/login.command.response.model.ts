export class LoginCommandResponseModel {
  token: string = '';
}
