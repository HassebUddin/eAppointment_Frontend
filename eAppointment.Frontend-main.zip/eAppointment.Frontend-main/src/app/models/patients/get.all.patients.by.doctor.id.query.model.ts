export class GetAllPatientsByDoctorIdQueryModel {
  doctorId: string = '';
}
