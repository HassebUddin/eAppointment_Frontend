export class GetPatientByIdQueryModel {
  id: number = 0;
}
