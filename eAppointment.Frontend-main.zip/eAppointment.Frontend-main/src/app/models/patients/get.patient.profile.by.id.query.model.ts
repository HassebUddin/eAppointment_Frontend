export class GetPatientProfileByIdQueryModel {
  id: number = 0;
}
