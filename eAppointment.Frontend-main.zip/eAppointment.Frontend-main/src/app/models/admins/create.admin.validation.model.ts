export class CreateAdminValidationModel {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  phoneNumber: string = '';
  userName: string = '';
  password: string = '';
  passwordAgain: string = '';
}
