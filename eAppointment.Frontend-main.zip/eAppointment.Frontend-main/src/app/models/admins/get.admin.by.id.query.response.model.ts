export class GetAdminByIdQueryResponseModel {
  firstName: string = '';
  lastName: string = '';
  phoneNumber: string = '';
  email: string = '';
  userName: string = '';
}
