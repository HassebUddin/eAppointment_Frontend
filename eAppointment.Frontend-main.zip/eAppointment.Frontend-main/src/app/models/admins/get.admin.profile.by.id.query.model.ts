export class GetAdminProfileByIdQueryModel {
  id: number = 0;
}
