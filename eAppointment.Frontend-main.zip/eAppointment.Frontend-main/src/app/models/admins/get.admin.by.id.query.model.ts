export class GetAdminByIdQueryModel {
  id: number = 0;
}
