export class GetAdminProfileByIdQueryResponseModel {
  firstName: string = '';
  lastName: string = '';
  phoneNumber: string = '';
  email: string = '';
  userName: string = '';
  profilePhotoContentType: string = '';
  profilePhotoBase64Content: string = '';
}
