export class GetAllCitiesQueryResponseModel {
  id: number = 0;
  name: string = '';
}
